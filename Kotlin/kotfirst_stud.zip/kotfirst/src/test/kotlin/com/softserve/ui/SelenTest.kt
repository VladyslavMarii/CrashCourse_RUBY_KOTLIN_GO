package com.softserve.ui

import io.github.bonigarcia.wdm.WebDriverManager
import org.junit.jupiter.api.*
import org.openqa.selenium.By
import org.openqa.selenium.Keys
import org.openqa.selenium.WebDriver
import org.openqa.selenium.chrome.ChromeDriver
import java.time.Duration

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SelenTest {
    private val BASE_URL = "https://www.google.com.ua/"
    private val IMPLICITLY_WAIT_SECONDS = 10L
    private var driver: ChromeDriver? = null

    @BeforeAll
    fun setup() {
        WebDriverManager.chromedriver().setup()
        //
        driver = ChromeDriver()
        //
        driver!!.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICITLY_WAIT_SECONDS)) // 0 by default
        driver!!.manage().window().maximize()
        println("@BeforeAll executed")
    }

    @AfterAll
    fun tear() {
        if (driver != null) {
            driver!!.quit() // close()
        }
        println("@AfterAll executed")
    }

    @BeforeEach
    @Throws(InterruptedException::class)
    fun setupThis() {
        driver!![BASE_URL]
        Thread.sleep(2000) // For Presentation
        println("\t@BeforeEach executed")
    }

    @AfterEach
    @Throws(InterruptedException::class)
    fun tearThis() {
        // Sign out
        // Clear session
        Thread.sleep(4000) // For Presentation
        println("\t@AfterEach executed")
    }

    @Test
    @Throws(InterruptedException::class)
    fun checkGoogleMac() {
        println("Start ...")
        //
        driver!!.findElement(By.name("q")).sendKeys("mac")
        Thread.sleep(2000) // For Presentation
        //
        //driver.findElement(By.cssSelector("button[type='submit']")).click();
        driver!!.findElement(By.name("q")).sendKeys(Keys.ENTER)
        //
        val mac = driver!!.findElement(By.xpath("//h3[text()='Mac']/..")).getAttribute("href")
        println("mac.href = $mac")
        Assertions.assertEquals("https://www.apple.com/ua/mac/", mac)
    }
}

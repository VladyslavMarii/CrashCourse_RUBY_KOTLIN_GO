package com.softserve.edu.stub

import com.softserve.edu.dao.IProductDao
import com.softserve.edu.service.ProductService
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test

class UnitTest {
    @Test
    fun checkLastDigits() {
        val productDao: IProductDao = ValidProductDaoStub()
        val productService = ProductService(productDao)
        //
        val expected = "123"
        val actual = productService.getLastDigits("")
        //
        Assertions.assertEquals(actual, expected, "LastDigits ERROR")
    }

    @Test
    fun checkOutDot() {
        val productDao: IProductDao = OutDotProductDaoStub()
        val productService = ProductService(productDao)
        //
        val expected = "aaa181"
        val actual = productService.getLastDigits("")
        //
        Assertions.assertEquals(actual, expected, "LastDigits ERROR")
    }

    @Test
    fun checkLastDot() {
        val productDao: IProductDao = LastDotProductDaoStub()
        val productService = ProductService(productDao)
        //
        val expected = ""
        val actual = productService.getLastDigits("")
        //
        Assertions.assertEquals(actual, expected, "LastDigits ERROR")
    }
}

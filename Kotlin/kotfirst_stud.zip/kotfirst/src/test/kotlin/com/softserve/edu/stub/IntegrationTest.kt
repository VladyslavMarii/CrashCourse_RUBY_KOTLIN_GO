package com.softserve.edu.stub

import com.softserve.edu.dao.ProductDao
import com.softserve.edu.service.ProductService
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test

class IntegrationTest {
    @Test
    fun checkLastDigits() {
        val productDao = ProductDao()
        val productService = ProductService(productDao)
        //
        val expected = "181"
        val actual = productService.getLastDigits("")
        //
        Assertions.assertEquals(actual, expected, "LastDigits ERROR")
    }
}

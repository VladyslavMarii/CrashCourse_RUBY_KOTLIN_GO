package com.softserve.edu.stub

import com.softserve.edu.dao.IProductDao


class ValidProductDaoStub : IProductDao {

    override fun getIPAddress(text: String?): String? {
        return "aaa.123"
    }
}

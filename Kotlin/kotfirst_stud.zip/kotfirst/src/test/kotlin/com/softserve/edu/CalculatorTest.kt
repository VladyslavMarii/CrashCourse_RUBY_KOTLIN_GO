package com.softserve.edu

import org.junit.jupiter.api.*
import org.junit.jupiter.api.function.Executable

class CalculatorTest {
    private val calculator = Calculator()

    @Test
    fun `Adding 1 and 3 should be equal to 4`() {
        Assertions.assertEquals(4, calculator.add(1, 3))
    }

    @Test
    fun `Dividing by zero should throw the DivideByZeroException`() {
        val exception = Assertions.assertThrows(DivideByZeroException::class.java) {
            calculator.divide(5, 0)
        }
        Assertions.assertEquals(5, exception.numerator)
    }

    @Test
    fun `The square of a number should be equal to that number multiplied in itself`() {
        Assertions.assertAll(
                Executable { Assertions.assertEquals(1, calculator.square(1)) },
                Executable { Assertions.assertEquals(4, calculator.square(2)) },
                Executable { Assertions.assertEquals(9, calculator.square(3)) }
        )
    }

}

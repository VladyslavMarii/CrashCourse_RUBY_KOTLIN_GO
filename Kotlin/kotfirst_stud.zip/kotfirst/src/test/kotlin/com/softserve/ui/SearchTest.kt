package com.softserve.ui

import io.github.bonigarcia.wdm.WebDriverManager
import org.apache.commons.io.FileUtils
import org.junit.jupiter.api.*
import org.openqa.selenium.*
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.interactions.Actions
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.StandardOpenOption
import java.text.SimpleDateFormat
import java.time.Duration
import java.util.*

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SearchTest {
    private val BASE_URL = "https://demo.opencart.com/index.php"
    private val IMPLICITLY_WAIT_SECONDS = 10L
    private val ONE_SECOND_DELAY = 1000L
    private val TIME_TEMPLATE = "yyyy-MM-dd_HH-mm-ss-S"
    private var driver: WebDriver? = null

    private fun takeScreenShot() {
        val currentTime = SimpleDateFormat(TIME_TEMPLATE).format(Date())
        val scrFile = (driver as TakesScreenshot?)!!.getScreenshotAs(OutputType.FILE)
        try {
            FileUtils.copyFile(scrFile, File("./" + currentTime + "_screenshot.png"))
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
            // Use Custom Exception
        }
    }

    private fun takePageSource() {
        val currentTime = SimpleDateFormat(TIME_TEMPLATE).format(Date())
        val pageSource = driver!!.pageSource
        val strToBytes = pageSource.toByteArray()
        val path = Paths.get("./" + currentTime + "_source.html")
        try {
            Files.write(path, strToBytes, StandardOpenOption.CREATE)
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }
    }

    private fun presentationSleep(seconds: Int = 1) {
        try {
            Thread.sleep(seconds * ONE_SECOND_DELAY) // For Presentation ONLY
        } catch (e: InterruptedException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }
    }

    @BeforeAll
    fun beforeClass() {
        WebDriverManager.chromedriver().setup()
        // WebDriverManager.firefoxdriver().setup();
        //
        val options = ChromeOptions()
        options.addArguments("--remote-allow-origins=*")
        driver = ChromeDriver(options)
        //driver = new ChromeDriver();
        //
        driver!!.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICITLY_WAIT_SECONDS)) // 0 by default
        driver!!.manage().window().maximize()
    }

    @AfterAll
    fun afterClass() {
        presentationSleep() // For Presentation ONLY
        if (driver != null) {
            driver!!.quit() // close()
        }
    }

    @BeforeEach
    fun beforeMethod() {
        driver!![BASE_URL]
        presentationSleep() // For Presentation ONLY
    }

    @AfterEach
    fun afterMethod() {
        // logout;
        /*
        if (!result.isSuccess()) {
            // Take Screenshot, save sourceCode, save to log, prepare report, Return to;
            // previous state, logout, etc.
            takeScreenShot();
            takePageSource();
            // driver.manage().deleteAllCookies(); // clear cache; delete cookie;
        }
        */
        presentationSleep() // For Presentation ONLY
    }

    private fun getProductByName(name: String): WebElement {
        var result: WebElement? = null
        val containers = driver!!.findElements(By.cssSelector("#product-list div.col"))
        for (current in containers) {
            if (current.findElement(By.cssSelector("h4 > a")).text == name) {
                result = current
                break
            }
        }
        if (result == null) {
            // Develop Custom Exception
            throw RuntimeException("WebElement by title/name: $name not found")
        }
        return result
    }

    @Test
    fun findByCss() {
        // Precondition
        val usd = driver!!.findElement(By.cssSelector("a[href='USD']"))
        println("*** 1. usd.isDisplayed() = " + usd.isDisplayed) // false
        // Choose Curency
        driver!!.findElement(By.cssSelector("#form-currency a.dropdown-toggle")).click()
        presentationSleep() // For Presentation ONLY
        println("*** 2. usd.isDisplayed() = " + usd.isDisplayed) // true
        //
        driver!!.findElement(By.cssSelector("a[href='USD']")).click()
        presentationSleep() // For Presentation ONLY
        //
        // Steps
        driver!!.findElement(By.cssSelector("div#search > input")).click()
        driver!!.findElement(By.cssSelector("#search > input")).clear()
        driver!!.findElement(By.cssSelector("#search > input")).sendKeys("mac")
        presentationSleep() // For Presentation ONLY
        //
        driver!!.findElement(By.cssSelector("button.btn.btn-light.btn-lg")).click()
        presentationSleep() // For Presentation ONLY
        //
        //driver.findElement(By.cssSelector("a:contains('MacBook')")).click(); // Selenium ERROR
        //driver.findElement(By.cssSelector("div.product-layout.product-grid h4:has(> a:contains('MacBook'))")).click(); // Selenium ERROR
        //driver.findElement(By.cssSelector("div.product-layout.product-grid h4:has(> a)")).click();
        //
        // Search a $("div.product-layout.product-grid h4 > a")
        // Search h4 $("div.product-layout.product-grid h4:has(> a)")
        // Search Price $("div.product-layout.product-grid h4:has(> a[href*='id=43']) + p + p")
        // Search Price $("div.product-layout.product-grid div:has(> h4 > a[href*='id=43']) > p[class='price']")
        // Search Price $("div.product-layout.product-grid div:has(> h4 > a[href*='id=43']) > p.price")
        //
        // Check
        //WebElement price = driver.findElement(By.cssSelector("div.product-layout.product-grid div:has(> h4 > a[href*='id=43']) > p.price")); // id=43 Hardcode Invalid Solution
        val price = getProductByName("MacBook").findElement(By.cssSelector("span.price-new"))
        //WebElement price = getProductByName("MacBook").findElement(By.xpath(".//p[@class='price']"));
        //WebElement price = driver.findElement(By.cssSelector("#content > div:nth-child(8) > div:nth-child(2) > div > div:nth-child(2) > div.caption > h4 > a"));
        //
        println("price.getText() = " + price.text)
        //
        // Scrolling by Actions
        val action = Actions(driver)
        action.moveToElement(price).perform()
        presentationSleep() // For Presentation ONLY
        //
        Assertions.assertTrue(price.text.contains("$602.00"))
        presentationSleep() // For Presentation ONLY
    }

    //Test // TODO
    fun findByXPath() {
        // Precondition
        // Choose Curency
        driver!!.findElement(By.xpath("//button[@class='btn btn-link dropdown-toggle']")).click()
        presentationSleep() // For Presentation ONLY
        driver!!.findElement(By.xpath("//button[@name='USD']")).click()
        presentationSleep() // For Presentation ONLY
        //
        // Steps
        // Type Search Field
        driver!!.findElement(By.xpath("//input[@name='search']")).click()
        //driver.findElement(By.xpath("//input[@name='search']")).clear();
        driver!!.findElement(By.xpath("//input[@placeholder='Search']")).clear()
        driver!!.findElement(By.xpath("//input[@name='search']")).sendKeys("mac")
        presentationSleep() // For Presentation ONLY
        //
        // Click Search Button
        driver!!.findElement(By.xpath("//button[@class='btn btn-default btn-lg']")).click()
        presentationSleep() // For Presentation ONLY
        //
        // $x("//a[text()='MacBook']/../..//p[contains(text(),'602')]")
        // "//a[text()='MacBook']/../../p[@class]"
        // "//a[text()='MacBook']/../following-sibling::p[@class='price']"
        val price = driver!!.findElement(By.xpath("//a[text()='MacBook']/../following-sibling::p[@class='price']"))
        // Scrolling by Action class
        val action = Actions(driver)
        action.moveToElement(price).perform()
        presentationSleep() // For Presentation ONLY
        // Check
        println("price.getText() = " + price.text)
        Assertions.assertTrue(price.text.contains("$602.00"))
        //
        // Return to Previous State
        presentationSleep() // For Presentation ONLY
    }
}

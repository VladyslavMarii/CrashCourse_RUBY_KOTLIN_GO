package com.softserve.edu.stub

import com.softserve.edu.dao.IProductDao

class OutDotProductDaoStub : IProductDao {

    override fun getIPAddress(text: String?): String? {
        return "aaa181"
    }
}

package com.softserve.edu.dao

interface IProductDao {

    fun getIPAddress(text: String?): String?
}

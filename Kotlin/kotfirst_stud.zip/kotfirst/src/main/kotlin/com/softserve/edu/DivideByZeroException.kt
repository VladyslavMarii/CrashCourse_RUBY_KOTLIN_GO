package com.softserve.edu

class DivideByZeroException(val numerator: Int) : Exception()

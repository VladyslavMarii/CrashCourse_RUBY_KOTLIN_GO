package com.softserve.edu.service

import com.softserve.edu.dao.IProductDao
import com.softserve.edu.dao.ProductDao

class ProductService {
    var productDao: IProductDao // Dependency Inversion
        private set

    constructor(productDao: IProductDao) {  // Dependency Injection
        println("Constructor ProductService")
        this.productDao = productDao
    }

    fun getLastDigits(text: String?): String? {
        val origin = productDao.getIPAddress(text)
        return origin?.substring(origin?.lastIndexOf(".")!! + 1)
    }
}

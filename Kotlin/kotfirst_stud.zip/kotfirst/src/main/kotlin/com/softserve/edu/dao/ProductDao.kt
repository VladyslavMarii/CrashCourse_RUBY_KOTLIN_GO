package com.softserve.edu.dao

class ProductDao : IProductDao {

    override fun getIPAddress(text: String?): String? {
        println("***Running ProductDao getIPAddress(String text)")
        return "192.168.103.181$text"
    }

}

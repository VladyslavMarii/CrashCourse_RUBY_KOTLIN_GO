package com.softserve.edu

import com.softserve.edu.dao.ProductDao
import com.softserve.edu.service.ProductService

object Appl {
    @JvmStatic
    fun main(args: Array<String>) {
        val productService = ProductService(ProductDao())
        println("result = " + productService.getLastDigits("text"))
    }
}

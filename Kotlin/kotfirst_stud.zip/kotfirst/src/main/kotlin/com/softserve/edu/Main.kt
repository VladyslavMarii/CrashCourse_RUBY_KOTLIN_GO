package com.softserve.edu

fun main() {
    println("Hello World!")
}